-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jan 02, 2003 at 08:17 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `ctnvietnam_qlns`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `qlns_administrator`
-- 

CREATE TABLE `qlns_administrator` (
  `ctn_id` int(11) NOT NULL auto_increment,
  `ctn_username` varchar(35) collate utf8_unicode_ci NOT NULL,
  `ctn_password` varchar(50) collate utf8_unicode_ci NOT NULL,
  `ctn_name` varchar(150) collate utf8_unicode_ci NOT NULL,
  `ctn_email` varchar(100) collate utf8_unicode_ci NOT NULL,
  `ctn_yahoo` varchar(150) collate utf8_unicode_ci NOT NULL,
  `ctn_mobile` varchar(150) collate utf8_unicode_ci NOT NULL,
  `ctn_content` text collate utf8_unicode_ci NOT NULL,
  `ctn_counterdb` int(11) NOT NULL,
  PRIMARY KEY  (`ctn_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `qlns_administrator`
-- 

INSERT INTO `qlns_administrator` VALUES (1, 'adminqlns', '599a50d6d28c5a010e00cd59a2cc150d', 'CTN Viá»‡t Nam', 'ctn@ctnvietnam.com', 'tranquangvinh_lbt', '0905094336', 'Adminstrator Website Quáº£n LÃ½ NhÃ¢n Sá»±', 37);

-- --------------------------------------------------------

-- 
-- Table structure for table `qlns_bophan`
-- 

CREATE TABLE `qlns_bophan` (
  `qlns_idbp` int(11) NOT NULL auto_increment,
  `qlns_mabp` int(11) NOT NULL,
  `qlns_mact` int(11) NOT NULL,
  `qlns_tenbophan` varchar(255) collate utf8_unicode_ci NOT NULL,
  `ctn_id` int(11) NOT NULL,
  PRIMARY KEY  (`qlns_idbp`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `qlns_bophan`
-- 

INSERT INTO `qlns_bophan` VALUES (2, 10, 10, 'Káº¿ ToÃ¡n<br>', 0);
INSERT INTO `qlns_bophan` VALUES (3, 11, 10, 'HÃ nh ChÃ­nh NhÃ¢n Sá»±<br>', 0);
INSERT INTO `qlns_bophan` VALUES (4, 12, 10, 'CÃ´ng Nghá»‡ ThÃ´ng Tin<br>', 0);
INSERT INTO `qlns_bophan` VALUES (5, 13, 10, 'XÃ¢y dá»±ng<br>', 0);
INSERT INTO `qlns_bophan` VALUES (6, 14, 10, 'Tá»• Äiá»‡n NÆ°á»›c<br>', 0);
INSERT INTO `qlns_bophan` VALUES (7, 15, 10, 'XÆ°á»Ÿng', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `qlns_chucvu`
-- 

CREATE TABLE `qlns_chucvu` (
  `qlns_idcv` int(11) NOT NULL auto_increment,
  `qlns_mact` int(11) NOT NULL,
  `qlns_mabp` int(11) NOT NULL,
  `qlns_macv` int(11) NOT NULL,
  `qlns_tenchucvu` varchar(255) collate utf8_unicode_ci NOT NULL,
  `ctn_id` int(11) NOT NULL,
  PRIMARY KEY  (`qlns_idcv`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

-- 
-- Dumping data for table `qlns_chucvu`
-- 

INSERT INTO `qlns_chucvu` VALUES (1, 0, 0, 10, 'Chá»§ Tá»‹ch Há»™i Äá»“ng Quáº£n Trá»‹<br>', 0);
INSERT INTO `qlns_chucvu` VALUES (2, 0, 0, 11, 'Tá»•ng GiÃ¡m Ä‘á»‘c<br>', 0);
INSERT INTO `qlns_chucvu` VALUES (3, 0, 0, 12, 'PhÃ³&nbsp; GiÃ¡m Äá»‘c<br>', 0);
INSERT INTO `qlns_chucvu` VALUES (4, 0, 0, 13, 'Káº¿ ToÃ¡n TrÆ°á»Ÿng<br>', 0);
INSERT INTO `qlns_chucvu` VALUES (5, 0, 0, 14, 'Káº¿ ToÃ¡n<br>', 0);
INSERT INTO `qlns_chucvu` VALUES (6, 0, 0, 15, 'NhÃ¢n Sá»±<br>', 0);
INSERT INTO `qlns_chucvu` VALUES (7, 0, 0, 16, 'HÃ nh ChÃ­nh<br>', 0);
INSERT INTO `qlns_chucvu` VALUES (8, 0, 0, 17, 'Thiáº¿t Káº¿<br>', 0);
INSERT INTO `qlns_chucvu` VALUES (9, 0, 0, 18, 'Táº¡p Vá»¥<br>', 0);
INSERT INTO `qlns_chucvu` VALUES (10, 0, 0, 19, 'Ká»¹ Thuáº­t<br>', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `qlns_congty`
-- 

CREATE TABLE `qlns_congty` (
  `qlns_idct` int(11) NOT NULL auto_increment,
  `qlns_mact` int(11) NOT NULL,
  `qlns_tencongty` varchar(255) collate utf8_unicode_ci NOT NULL,
  `ctn_id` int(11) NOT NULL,
  PRIMARY KEY  (`qlns_idct`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `qlns_congty`
-- 

INSERT INTO `qlns_congty` VALUES (1, 10, 'CTN Viá»‡t Nam<br>', 0);
INSERT INTO `qlns_congty` VALUES (3, 11, 'Truyá»n HÃ¬nh CÃ¡p QuÃ£ng NgÃ£i<br>', 0);
INSERT INTO `qlns_congty` VALUES (4, 12, 'Truyá»n HÃ¬nh CÃ¡p Báº¡c LiÃªu<br>', 0);
INSERT INTO `qlns_congty` VALUES (5, 13, 'Truyá»n HÃ¬nh CÃ¡p QuÃ£ng BÃ¬nh<br>', 0);
INSERT INTO `qlns_congty` VALUES (6, 14, 'Truyá»n HÃ¬nh CÃ¡p Kon Tum<br>', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `qlns_giadinh`
-- 

CREATE TABLE `qlns_giadinh` (
  `qlns_idgdnv` int(11) NOT NULL auto_increment,
  `qlns_mahsnv` int(11) NOT NULL,
  `qlns_hotencha` varchar(255) collate utf8_unicode_ci NOT NULL,
  `qlns_hotenme` varchar(255) collate utf8_unicode_ci NOT NULL,
  `qlns_nghenghiepc` varchar(255) collate utf8_unicode_ci NOT NULL,
  `qlns_nghenghiepm` varchar(255) collate utf8_unicode_ci NOT NULL,
  `qlns_anhem` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`qlns_idgdnv`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `qlns_giadinh`
-- 

INSERT INTO `qlns_giadinh` VALUES (1, 10121714, 'LÃª Há»“ng ', 'Pháº¡m Thá»‹ ', 'Ká»¹ SÆ°', 'BÃ¡c Sá»¹', 'Anh Trai : LÃª Há»“ng Quang <br>CÃ¡c ghi chÃº khÃ¡c<br>');

-- --------------------------------------------------------

-- 
-- Table structure for table `qlns_hosonhanvien`
-- 

CREATE TABLE `qlns_hosonhanvien` (
  `qlns_hsnv` int(11) NOT NULL auto_increment,
  `qlns_mact` int(11) NOT NULL,
  `qlns_mabp` int(11) NOT NULL,
  `qlns_macv` int(11) NOT NULL,
  `qlns_manv` int(11) NOT NULL,
  `qlns_mahsnv` int(11) NOT NULL,
  `qlns_honv` varchar(255) collate utf8_unicode_ci NOT NULL,
  `qlns_tennv` varchar(255) collate utf8_unicode_ci NOT NULL,
  `qlns_ngaysinh` varchar(255) collate utf8_unicode_ci NOT NULL,
  `qlns_gioitinh` int(1) NOT NULL default '0',
  `qlns_email` varchar(255) collate utf8_unicode_ci NOT NULL,
  `qlns_nvcongty` varchar(255) collate utf8_unicode_ci NOT NULL,
  `qlns_anhnvien` varchar(255) collate utf8_unicode_ci NOT NULL,
  `qlns_tinhtrangnv` varchar(255) collate utf8_unicode_ci NOT NULL,
  `qlns_macmnd` int(11) NOT NULL,
  `qlns_ghichu` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`qlns_hsnv`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

-- 
-- Dumping data for table `qlns_hosonhanvien`
-- 

INSERT INTO `qlns_hosonhanvien` VALUES (8, 10, 12, 17, 15, 10121715, 'Tráº§n Quang', 'Vinh ', '01/11/1984', 1, 'designwebvn@gmail.com', '01/07/2009', 'News_Vinhtq.jpg', '1', 200477789, 'NhÃ¢n viÃªn ChÃ­nh Thá»©c<br>');
INSERT INTO `qlns_hosonhanvien` VALUES (9, 10, 12, 17, 14, 10121714, 'LÃª Há»“ng', 'QuÃ¢n', '20/02/2009', 1, 'hongquan@gmail.com', '09/07/2009', 'Quanlh.jpg', '1', 200577789, 'NhÃ¢n ViÃªn ChÃ­nh Thá»©c<br>');
INSERT INTO `qlns_hosonhanvien` VALUES (10, 10, 12, 17, 16, 10121716, 'LÃª Trá»ng', 'Quá»³nh', '10/10/1983', 1, 'trongquynhit', '01/07/2008', 'News_Quynhlt.jpg', '1', 200677789, 'LÃª Trá»ng Quá»³nh<br>');
INSERT INTO `qlns_hosonhanvien` VALUES (11, 10, 11, 15, 17, 10111517, 'NgÃ´ HoÃ ng', 'QuÃ¢n', '20/02/1979', 0, 'hoangquan@gmail.com', '20/02/2009', 'Ngo_Hoang_Quan.jpg', '1', 201677789, '<br>');
INSERT INTO `qlns_hosonhanvien` VALUES (12, 10, 12, 17, 18, 10121718, 'LÃª Kháº¯c Gia', 'KhÃ¡nh', '20/02/1983', 1, 'giakhanhctn@gmail.com', '01/07/2008', 'khanhcutcho.jpg', '1', 210477789, '<br>');
INSERT INTO `qlns_hosonhanvien` VALUES (13, 10, 13, 12, 19, 10131219, 'Nguyá»…n', 'VÅ©', '23/02/1984', 1, 'vuctn@gmail.com', '01/07/2008', 'vuqlxd.jpg', '1', 211477723, '<br>');
INSERT INTO `qlns_hosonhanvien` VALUES (14, 10, 10, 13, 20, 10101320, 'Huá»³nh Thá»‹ ', 'PhÃº', '04/09/1982', 0, 'phukt@ctnvietnam.com', '01/07/2008', 'c_phu.jpg', '1', 211477781, '<br>');
INSERT INTO `qlns_hosonhanvien` VALUES (15, 10, 10, 14, 21, 10101421, 'VÃµ Thá»‹ Thanh', 'DuyÃªn', '21/09/1983', 0, 'thanhduyen@ctnvietnam.com', '01/07/2008', 'duyen.jpg', '1', 200377777, '<br>');
INSERT INTO `qlns_hosonhanvien` VALUES (16, 10, 10, 14, 22, 10101422, 'Tráº§n thá»‹', 'ToÃ n', '23/09/1985', 0, 'toankt@gmail.com', '01/07/2008', 'toankt.jpg', '1', 201377777, '<br>');
INSERT INTO `qlns_hosonhanvien` VALUES (17, 10, 13, 19, 23, 10131923, 'Tráº§n CÃ´ng', 'Tháº¡ch', '12/2/1977', 1, 'thach@gmai.com', '5/7/2008', 'A_Thanh.jpg', '1', 200377557, '<br>');
INSERT INTO `qlns_hosonhanvien` VALUES (18, 10, 14, 19, 24, 10141924, 'LÃª Nho', 'Tháº¯ng', '23/11/1977', 1, 'nhothang@ctnvietnam.com', '20/07/2008', 'a_thang.jpg', '1', 200375557, '<br>');
INSERT INTO `qlns_hosonhanvien` VALUES (19, 10, 15, 19, 25, 10151925, 'Nguyá»…n Viáº¿t', ' Tuáº¥n', '07/02/1980', 1, 'tuannv', '01/07/2008', 'a_tuan.jpg', '1', 200355557, '<br>');
INSERT INTO `qlns_hosonhanvien` VALUES (20, 10, 10, 14, 26, 10101426, 'Nguyá»…n Thá»‹ ', 'ThÆ°Æ¡ng', '09/12/1983', 0, 'Thuongkt@ctnvietnam.com', '01/01/2009', 'login.png', '0', 209435032, '<br>');

-- --------------------------------------------------------

-- 
-- Table structure for table `qlns_khenthuongkl`
-- 

CREATE TABLE `qlns_khenthuongkl` (
  `qlns_idktkl` int(11) NOT NULL auto_increment,
  `qlns_mahsnv` int(11) NOT NULL,
  `qlns_hinhthuc` text collate utf8_unicode_ci NOT NULL,
  `qlns_lydo` text collate utf8_unicode_ci NOT NULL,
  `qlns_ngay` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`qlns_idktkl`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `qlns_khenthuongkl`
-- 

INSERT INTO `qlns_khenthuongkl` VALUES (1, 10121714, 'Du Lá»‹ch ÄÃ  Láº¡t&nbsp; <br>', 'ThÃ nh tÃ­ch xuáº¥t sáº¯c trong cÃ´ng tÃ¡c. Thiáº¿t káº¿ ThÆ°Æ¡ng hiá»‡u taxi.<br>', '06/03/2009');

-- --------------------------------------------------------

-- 
-- Table structure for table `qlns_lylich`
-- 

CREATE TABLE `qlns_lylich` (
  `qlns_idll` int(11) NOT NULL auto_increment,
  `qlns_mahsnv` int(11) NOT NULL,
  `qlns_tinhtranghn` int(1) NOT NULL default '0',
  `qlns_quoctich` varchar(255) collate utf8_unicode_ci NOT NULL,
  `qlns_dienthoainha` varchar(255) collate utf8_unicode_ci NOT NULL,
  `qlns_dthoaididong` varchar(255) collate utf8_unicode_ci NOT NULL,
  `qlns_diachi` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`qlns_idll`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `qlns_lylich`
-- 

INSERT INTO `qlns_lylich` VALUES (1, 10121714, 1, 'Viá»‡t Nam ', '0542234897', '0988323489', 'PhÃº BÃ i Thá»«a ThiÃªn Huáº¿<br>');
INSERT INTO `qlns_lylich` VALUES (2, 10121715, 1, 'Viá»‡t Nam', '0905094336', '0905094336', 'Quáº£ng Nam<br>');
